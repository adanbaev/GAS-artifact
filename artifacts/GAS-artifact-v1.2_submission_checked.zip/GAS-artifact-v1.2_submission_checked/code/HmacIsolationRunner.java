package kg.gov.nas.licensedb.bench;

import kg.gov.nas.licensedb.dto.FreqModel;
import kg.gov.nas.licensedb.dto.OwnerModel;
import kg.gov.nas.licensedb.dto.SiteModel;
import kg.gov.nas.licensedb.enums.FreqMode;
import kg.gov.nas.licensedb.enums.FreqType;
import kg.gov.nas.licensedb.util.SecurityUtil;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Experiment E1 — FALLBACK runner (no external dependency).
 *
 * Use this ONLY if the JMH benchmark ({@link HmacMicrobenchmark}) is inconvenient to set up
 * (e.g. annotation processing not enabled). It measures the same three quantities with a plain
 * nanoTime loop: warm-up, then several measured batches, reporting per-op time in nanoseconds
 * with mean / median / p95 / p99 across batches.
 *
 * JMH remains the preferred, reviewer-grade tool because it controls JIT warm-up, dead-code
 * elimination and forking automatically. This fallback is a pragmatic safety net.
 *
 * Run main() from IntelliJ. Output: console + e1-hmac-fallback.csv.
 */
public class HmacIsolationRunner {

    private static final int WARMUP_ITERS = 2_000_000;
    private static final int BATCHES = 30;
    private static final int OPS_PER_BATCH = 1_000_000;

    public static void main(String[] args) throws Exception {
        OwnerModel owner = new OwnerModel();
        owner.setOwnerId(123456L);
        owner.setOwnerName("Государственное предприятие радиочастотной службы");
        owner.setIssueDate(LocalDate.of(2021, 3, 15));
        owner.setExpireDate(LocalDate.of(2026, 3, 14));

        SiteModel site = new SiteModel();
        site.setSiteId(78901L);
        site.setLatitude0(42); site.setLatitude1(52); site.setLatitude2(30);
        site.setLongitude0(74); site.setLongitude1(36); site.setLongitude2(15);

        FreqModel freq = new FreqModel();
        freq.setFreqId(456789L);
        freq.setNominal(145.625);
        freq.setBand(16000.0);
        freq.setMode(FreqMode.SIMPLEX);
        freq.setType(FreqType.ANALOGUE);
        freq.setChannel(12);
        freq.setDeviation(5.0);
        freq.setSnch(12.5);
        freq.setInco(true);
        freq.setSatRadius(0.0);
        freq.setMobStan(3);
        freq.setMeaning("F3E");

        final String canonical = SecurityUtil.canonicalFreqString(owner, site, freq);
        final byte[] canonicalBytes = canonical.getBytes(StandardCharsets.UTF_8);
        final byte[] secretBytes = SecurityUtil.getSignatureSecret().getBytes(StandardCharsets.UTF_8);

        System.out.println("[E1-fallback] canonical length = " + canonicalBytes.length + " bytes");
        System.out.println("[E1-fallback] canonical = " + canonical);

        // Warm-up (JIT) for all three operations
        long sink = 0;
        for (int i = 0; i < WARMUP_ITERS; i++) {
            sink += SecurityUtil.canonicalFreqString(owner, site, freq).length();
            sink += hmacHex(canonicalBytes, secretBytes).length();
            sink += SecurityUtil.freqDataHash(owner, site, freq).length();
        }
        if (sink == Long.MIN_VALUE) System.out.println("noop " + sink); // prevent DCE

        try (FileWriter fw = new FileWriter("e1-hmac-fallback.csv", false)) {
            fw.write("operation,batch,ns_per_op\n");
            List<Double> canon = measure("canonicalStringOnly", fw, BATCHES, OPS_PER_BATCH,
                    () -> SecurityUtil.canonicalFreqString(owner, site, freq).length());
            List<Double> hmac = measure("hmacOnly", fw, BATCHES, OPS_PER_BATCH,
                    () -> hmacHex(canonicalBytes, secretBytes).length());
            List<Double> full = measure("fingerprintFull", fw, BATCHES, OPS_PER_BATCH,
                    () -> SecurityUtil.freqDataHash(owner, site, freq).length());

            System.out.println("\n=== E1 fallback results (ns/op) ===");
            report("canonicalStringOnly (Alg.1)", canon);
            report("hmacOnly (Alg.2 MAC)        ", hmac);
            report("fingerprintFull (Alg.1+2)   ", full);
        }
        System.out.println("\nCSV saved to e1-hmac-fallback.csv");
    }

    private interface Op { long run(); }

    private static List<Double> measure(String name, FileWriter fw, int batches, int opsPerBatch, Op op) throws Exception {
        List<Double> nsPerOp = new ArrayList<>(batches);
        for (int b = 1; b <= batches; b++) {
            long sink = 0;
            long t0 = System.nanoTime();
            for (int i = 0; i < opsPerBatch; i++) sink += op.run();
            long t1 = System.nanoTime();
            if (sink == Long.MIN_VALUE) System.out.println(sink); // prevent DCE
            double perOp = (double) (t1 - t0) / opsPerBatch;
            nsPerOp.add(perOp);
            fw.write(String.format(Locale.US, "%s,%d,%.3f%n", name, b, perOp));
            fw.flush();
        }
        return nsPerOp;
    }

    private static String hmacHex(byte[] message, byte[] secret) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            byte[] out = mac.doFinal(message);
            StringBuilder hex = new StringBuilder(out.length * 2);
            for (byte x : out) hex.append(String.format("%02x", x));
            return hex.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void report(String label, List<Double> xs) {
        List<Double> s = new ArrayList<>(xs);
        s.sort(Double::compareTo);
        double mean = xs.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        System.out.printf(Locale.US, "%s | mean=%.1f | median=%.1f | p95=%.1f | p99=%.1f ns/op%n",
                label, mean, pct(s, 50), pct(s, 95), pct(s, 99));
    }

    private static double pct(List<Double> sorted, double p) {
        if (sorted.isEmpty()) return 0;
        if (sorted.size() == 1) return sorted.get(0);
        double idx = p / 100.0 * (sorted.size() - 1);
        int lo = (int) Math.floor(idx), hi = (int) Math.ceil(idx);
        if (lo == hi) return sorted.get(lo);
        return sorted.get(lo) * (1 - (idx - lo)) + sorted.get(hi) * (idx - lo);
    }
}
