package kg.gov.nas.licensedb.bench;

import kg.gov.nas.licensedb.dto.FreqModel;
import kg.gov.nas.licensedb.dto.OwnerModel;
import kg.gov.nas.licensedb.dto.SiteModel;
import kg.gov.nas.licensedb.enums.FreqMode;
import kg.gov.nas.licensedb.enums.FreqType;
import kg.gov.nas.licensedb.util.SecurityUtil;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.runner.Runner;
import org.openjdk.jmh.runner.options.Options;
import org.openjdk.jmh.runner.options.OptionsBuilder;
import org.openjdk.jmh.results.format.ResultFormatType;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/**
 * Experiment E1 — isolated cost of the record fingerprint (Algorithm 1 + Algorithm 2).
 *
 * Why this benchmark exists:
 * Reviewer #1 noted that in the end-to-end write-path benchmark (Table 3) the SIGNATURE_ONLY
 * overhead is dominated by system noise (even slightly negative at some N), so the claim that
 * fingerprinting is "almost free" is not convincing. This JMH benchmark removes the database and
 * OS write path entirely and measures the ABSOLUTE cost of:
 *   (a) building the deterministic canonical string  (Algorithm 1),
 *   (b) computing HMAC-SHA-256 over a precomputed canonical string (Algorithm 2, MAC only),
 *   (c) the full fingerprint = (a) + (b)  ==  SecurityUtil.freqDataHash(...).
 *
 * The result (ns/op) is compared in the paper against the per-write latency floor
 * (~1000/medianTPS ms ~= 3.3 ms at ~300 TPS). If the full fingerprint costs a few microseconds,
 * its share of write latency is ~0.1%, which EXPLAINS — rather than hand-waves — why it is
 * invisible in Table 3.
 *
 * How to run (from IntelliJ): run main() below, or run the JMH benchmark class directly.
 * Output: console summary + e1-hmac-jmh.csv in the working directory.
 *
 * NOTE: requires the JMH annotation processor to be active. In IntelliJ this is automatic for
 * Maven projects; if not, enable Settings > Build > Compiler > Annotation Processors.
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Benchmark)
@Warmup(iterations = 5, time = 2)
@Measurement(iterations = 10, time = 2)
@Fork(5)
public class HmacMicrobenchmark {

    private OwnerModel owner;
    private SiteModel site;
    private FreqModel freq;

    /** Precomputed canonical string, so {@link #hmacOnly()} measures only the MAC, not Algorithm 1. */
    private String canonical;
    private byte[] canonicalBytes;
    private byte[] secretBytes;

    @Setup(Level.Trial)
    public void setup() {
        // A representative registry record populating all 23 protected fields
        // (OwnerModel: 4, SiteModel: 7, FreqModel: 12).
        owner = new OwnerModel();
        owner.setOwnerId(123456L);
        owner.setOwnerName("Государственное предприятие радиочастотной службы");
        owner.setIssueDate(LocalDate.of(2021, 3, 15));
        owner.setExpireDate(LocalDate.of(2026, 3, 14));

        site = new SiteModel();
        site.setSiteId(78901L);
        site.setLatitude0(42);
        site.setLatitude1(52);
        site.setLatitude2(30);
        site.setLongitude0(74);
        site.setLongitude1(36);
        site.setLongitude2(15);

        freq = new FreqModel();
        freq.setFreqId(456789L);
        freq.setNominal(145.625);
        freq.setBand(16000.0);
        freq.setMode(FreqMode.SIMPLEX);
        freq.setType(FreqType.ANALOGUE);
        freq.setChannel(12);
        freq.setDeviation(5.0);
        freq.setSnch(12.5);
        freq.setInco(true);
        freq.setSatRadius(0.0);
        freq.setMobStan(3);
        freq.setMeaning("F3E");

        canonical = SecurityUtil.canonicalFreqString(owner, site, freq);
        canonicalBytes = canonical.getBytes(StandardCharsets.UTF_8);
        secretBytes = SecurityUtil.getSignatureSecret().getBytes(StandardCharsets.UTF_8);

        System.out.println("[E1] canonical string length = " + canonicalBytes.length + " bytes");
        System.out.println("[E1] canonical = " + canonical);
    }

    /** Algorithm 1 only: deterministic length-prefixed canonical string construction. */
    @Benchmark
    public String canonicalStringOnly() {
        return SecurityUtil.canonicalFreqString(owner, site, freq);
    }

    /** Algorithm 2 only: HMAC-SHA-256 over the precomputed canonical string (isolates MAC cost). */
    @Benchmark
    public String hmacOnly() throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secretBytes, "HmacSHA256"));
        byte[] out = mac.doFinal(canonicalBytes);
        StringBuilder hex = new StringBuilder(out.length * 2);
        for (byte b : out) hex.append(String.format("%02x", b));
        return hex.toString();
    }

    /** Full per-write fingerprint = Algorithm 1 + Algorithm 2 (exactly what the write path calls). */
    @Benchmark
    public String fingerprintFull() {
        return SecurityUtil.freqDataHash(owner, site, freq);
    }

    public static void main(String[] args) throws Exception {
        Options opt = new OptionsBuilder()
                .include(HmacMicrobenchmark.class.getSimpleName())
                .resultFormat(ResultFormatType.CSV)
                .result("e1-hmac-jmh.csv")
                .build();
        new Runner(opt).run();
    }
}
