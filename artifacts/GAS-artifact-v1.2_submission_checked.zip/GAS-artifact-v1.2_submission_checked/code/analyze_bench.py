#!/usr/bin/env python3
"""
E6 — analysis of benchmark CSVs for the ARRAY revision.

Computes robust statistics (median, IQR, SD) and bootstrap 95% confidence
intervals on the overhead vs STANDARD, and renders publication tables + figures.

Auto-detects the stage from the data:
  * SINGLE-THREAD  (Stage 1): one thread value -> Table 3 style (overhead vs STANDARD per N).
  * CONCURRENT     (Stage 2): several thread values -> aggregate TPS, overhead per thread count,
                              and the scalability coefficient Scal(T)=TPS(T)/TPS(1).

CSV schema (written by MicrobenchmarkRunner):
  mode,n_ops,repeat,total_ms,avg_ms_per_op,tps,threads,mean_ms,stddev_ms,min_ms,max_ms,iqr_ms,k_value
Per-rep rows have repeat>=1; summary rows (repeat=-1) are ignored and recomputed here.

Usage:
  python analyze_bench.py <bench-results.csv> [more.csv ...] [--out OUTDIR] [--boot 10000]
"""
import argparse
import os
import sys
import numpy as np
import pandas as pd

BASELINE = "STANDARD"


def load(paths):
    frames = []
    for p in paths:
        df = pd.read_csv(p)
        df.columns = [c.strip() for c in df.columns]
        frames.append(df)
    df = pd.concat(frames, ignore_index=True)
    for col in ["n_ops", "repeat", "total_ms", "tps", "threads", "k_value"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    # keep only per-rep measurement rows
    df = df[df["repeat"] >= 1].copy()
    if "k_value" in df.columns:
        df["k_value"] = df["k_value"].fillna(-1)
    return df


def boot_ci_overhead(base_vals, mode_vals, n_boot, metric="time"):
    """Bootstrap 95% CI of overhead vs baseline.
    metric='time': overhead = (med(mode_total_ms) - med(base)) / med(base)   (lower TPS => positive)
    metric='tps' : reduction = (med(base_tps) - med(mode)) / med(base)
    """
    base_vals = np.asarray(base_vals, float)
    mode_vals = np.asarray(mode_vals, float)
    if len(base_vals) == 0 or len(mode_vals) == 0:
        return (np.nan, np.nan, np.nan)
    rng = np.random.default_rng(42)
    point = None
    samples = np.empty(n_boot)
    for i in range(n_boot):
        b = rng.choice(base_vals, len(base_vals), replace=True)
        m = rng.choice(mode_vals, len(mode_vals), replace=True)
        mb, mm = np.median(b), np.median(m)
        if metric == "time":
            samples[i] = 100.0 * (mm - mb) / mb
        else:
            samples[i] = 100.0 * (mb - mm) / mb
    mb, mm = np.median(base_vals), np.median(mode_vals)
    point = 100.0 * (mm - mb) / mb if metric == "time" else 100.0 * (mb - mm) / mb
    lo, hi = np.percentile(samples, [2.5, 97.5])
    return (point, lo, hi)


def stats_block(vals):
    vals = np.asarray(vals, float)
    q25, q75 = np.percentile(vals, [25, 75])
    return dict(median=np.median(vals), mean=vals.mean(),
                sd=vals.std(ddof=1) if len(vals) > 1 else 0.0,
                iqr=q75 - q25, n=len(vals))


def analyze_single(df, outdir, n_boot):
    rows = []
    for n in sorted(df["n_ops"].dropna().unique()):
        sub = df[df["n_ops"] == n]
        base = sub[sub["mode"] == BASELINE]["total_ms"].values
        for mode in sub["mode"].unique():
            mv = sub[sub["mode"] == mode]
            st = stats_block(mv["total_ms"].values)
            tps_med = np.median(mv["tps"].values)
            if mode == BASELINE:
                oh = (0.0, 0.0, 0.0)
            else:
                oh = boot_ci_overhead(base, mv["total_ms"].values, n_boot, "time")
            rows.append(dict(N=int(n), mode=mode, tps_median=round(tps_med, 2),
                             total_ms_median=round(st["median"], 1),
                             sd_ms=round(st["sd"], 1), iqr_ms=round(st["iqr"], 1),
                             overhead_pct=round(oh[0], 3), ci_lo=round(oh[1], 3),
                             ci_hi=round(oh[2], 3), runs=st["n"]))
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(outdir, "analysis_single.csv"), index=False)
    _md_table(out, os.path.join(outdir, "analysis_single.md"),
              title="Single-thread overhead vs STANDARD (median total time, bootstrap 95% CI)")
    _fig_single_throughput(out, outdir)
    _fig_single_overhead(out, outdir)
    return out


def analyze_concurrent(df, outdir, n_boot):
    rows = []
    threads = sorted(df["threads"].dropna().unique())
    modes = list(dict.fromkeys(df["mode"]))
    # median TPS at 1 thread for scalability
    tps1 = {}
    for mode in modes:
        m1 = df[(df["mode"] == mode) & (df["threads"] == 1)]["tps"].values
        tps1[mode] = np.median(m1) if len(m1) else np.nan
    for t in threads:
        sub = df[df["threads"] == t]
        base = sub[sub["mode"] == BASELINE]["tps"].values
        for mode in modes:
            mv = sub[sub["mode"] == mode]["tps"].values
            if len(mv) == 0:
                continue
            st = stats_block(mv)
            if mode == BASELINE:
                red = (0.0, 0.0, 0.0)
            else:
                red = boot_ci_overhead(base, mv, n_boot, "tps")
            scal = (np.median(mv) / tps1[mode]) if tps1.get(mode) else np.nan
            rows.append(dict(threads=int(t), mode=mode,
                             aggTPS_median=round(st["median"], 2),
                             iqr_tps=round(st["iqr"], 2), sd_tps=round(st["sd"], 2),
                             tps_reduction_vs_std_pct=round(red[0], 2),
                             ci_lo=round(red[1], 2), ci_hi=round(red[2], 2),
                             scalability=round(scal, 3), runs=st["n"]))
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(outdir, "analysis_concurrent.csv"), index=False)
    _md_table(out, os.path.join(outdir, "analysis_concurrent.md"),
              title="Concurrent aggregate TPS, reduction vs STANDARD, and scalability Scal(T)=TPS(T)/TPS(1)")
    _fig_concurrent(out, outdir)
    return out


def _md_table(df, path, title):
    with open(path, "w", encoding="utf-8") as f:
        f.write("# " + title + "\n\n")
        f.write("| " + " | ".join(df.columns) + " |\n")
        f.write("|" + "|".join(["---"] * len(df.columns)) + "|\n")
        for _, r in df.iterrows():
            f.write("| " + " | ".join(str(r[c]) for c in df.columns) + " |\n")


def _fig_single_throughput(out, outdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    modes = ["STANDARD", "SIGNATURE_ONLY", "CHAIN_ONLY", "FULL_HYBRID"]
    plt.figure(figsize=(7, 4.2))
    for mode in modes:
        d = out[out["mode"] == mode].sort_values("N")
        if d.empty:
            continue
        plt.plot(d["N"], d["tps_median"], marker="o", linewidth=2, label=mode)
    plt.xscale("log")
    plt.xlabel("Number of records (N)")
    plt.ylabel("Median throughput (TPS)")
    plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5), fontsize=8.5)
    plt.grid(alpha=0.3)
    plt.subplots_adjust(left=0.12, right=0.72, top=0.92, bottom=0.13)
    plt.savefig(os.path.join(outdir, "fig_3_single_throughput.png"), dpi=160)
    plt.close()


def _fig_single_overhead(out, outdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    modes = [m for m in out["mode"].unique() if m not in (BASELINE, "STRICT_ONLY")]
    plt.figure(figsize=(7, 4.2))
    for mode in modes:
        d = out[out["mode"] == mode].sort_values("N")
        yerr = [d["overhead_pct"] - d["ci_lo"], d["ci_hi"] - d["overhead_pct"]]
        plt.errorbar(d["N"], d["overhead_pct"], yerr=yerr, marker="o", capsize=3, label=mode)
    plt.xscale("log")
    plt.axhline(0, ls="--", lw=0.8, color="gray")
    plt.xlabel("N (updates)")
    plt.ylabel("Overhead vs STANDARD (%)")
    plt.title("Single-thread write overhead (median, bootstrap 95% CI)")
    plt.legend(); plt.grid(alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "fig_4_single_overhead.png"), dpi=160)
    plt.close()


def _fig_concurrent(out, outdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    modes = list(dict.fromkeys(out["mode"]))
    # throughput vs threads
    plt.figure(figsize=(7, 4.2))
    for mode in modes:
        d = out[out["mode"] == mode].sort_values("threads")
        plt.plot(d["threads"], d["aggTPS_median"], marker="o", label=mode)
    plt.xlabel("Threads"); plt.ylabel("Aggregate TPS (median)")
    plt.title("Concurrent throughput vs threads")
    plt.grid(alpha=0.3); plt.subplots_adjust(left=0.11, right=0.72, top=0.90, bottom=0.13); plt.legend(fontsize=8.5, loc="center left", bbox_to_anchor=(1.02, 0.5))
    plt.savefig(os.path.join(outdir, "fig_5_concurrent_tps.png"), dpi=160)
    plt.close()
    # scalability
    plt.figure(figsize=(7, 4.2))
    for mode in modes:
        d = out[out["mode"] == mode].sort_values("threads")
        plt.plot(d["threads"], d["scalability"], marker="s", label=mode)
    th = sorted(out["threads"].unique())
    plt.plot(th, [t / th[0] for t in th], ls="--", color="gray", label="ideal (linear)")
    plt.xlabel("Threads"); plt.ylabel("Scalability  TPS(T)/TPS(1)")
    plt.title("Scalability: STRICT (flat) vs CHECKPOINT (saturating)")
    plt.legend(); plt.grid(alpha=0.3); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "fig_6_scalability.png"), dpi=160)
    plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="+")
    ap.add_argument("--out", default="analysis_out")
    ap.add_argument("--boot", type=int, default=10000)
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    df = load(args.csv)
    if df.empty:
        print("No per-rep rows found."); sys.exit(1)

    n_threads = df["threads"].dropna().nunique()
    concurrent = n_threads > 1
    print(f"Loaded {len(df)} measurement rows | distinct thread counts: {n_threads} "
          f"-> {'CONCURRENT' if concurrent else 'SINGLE-THREAD'} analysis")

    if concurrent:
        out = analyze_concurrent(df, args.out, args.boot)
    else:
        out = analyze_single(df, args.out, args.boot)
    print(out.to_string(index=False))
    print(f"\nWrote tables + figures to: {args.out}/")


if __name__ == "__main__":
    main()
