package kg.gov.nas.licensedb.bench;

import kg.gov.nas.licensedb.LicensedbApplication;
import kg.gov.nas.licensedb.dao.FreqDao;
import kg.gov.nas.licensedb.dto.FreqView;
import kg.gov.nas.licensedb.service.FreqCrudService;
import kg.gov.nas.licensedb.service.IntegrityService;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.FileWriter;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class MicrobenchmarkRunner {

    // Размеры для тестирования
    private static final int[] SIZES = new int[]{1000, 5000, 10000, 50000, 100000};

    // Операции прогрева (на уровне сервисов, как в нашей методологии)
    private static final int WARMUP_OPS = 10_000;

    // Повторяется для каждого (mode, N) для уменьшения шума
    private static final int REPEATS = 30;

    // Checkpoint K (used when integrityEnabled=true; IntegrityService uses CHECKPOINT strategy)
    private static final int CHECKPOINT_K = 100;

    // K-sensitivity experiment
    private static final int K_SENSITIVITY_N = 100_000;
    private static final int[] K_SENSITIVITY_K_VALUES = new int[]{50, 100, 500};

    // --- Concurrency benchmark (Stage 2, experiments E2 + E3) ---
    // Sized for an overnight run (~10 h): the concurrency effects (STRICT non-scaling, checkpoint
    // saturation) are large, so stable medians do NOT need the 30-run x 100k rigor of Stage 1.
    // ops/thread=3000 with a 500-record slice => ~6 cycles/thread and ~30 checkpoint flushes (K=100),
    // i.e. steady state is reached. 12 repeats give stable median + IQR. Raise back if time allows.
    private static final int[] CONCURRENT_THREAD_COUNTS = new int[]{1, 2, 4, 8, 16, 32};
    private static final int CONCURRENT_OPS_PER_THREAD = 3_000;    // work per thread, constant across thread counts
    private static final int CONCURRENT_RECORDS_PER_THREAD = 500;  // disjoint row slice per thread (no cross-thread InnoDB row contention)
    private static final int CONCURRENT_REPEATS = 16;              // repeats per (mode, threads) cell -> median/IQR/SD (margin over the minimum)
    private static final int CONCURRENT_MAX_RECORDS =
            CONCURRENT_THREAD_COUNTS[CONCURRENT_THREAD_COUNTS.length - 1] * CONCURRENT_RECORDS_PER_THREAD;

    // STRICT_ONLY added so the strongest audit mode (per-write global last_hash) is benchmarked
    // alongside CHECKPOINT — directly answers Reviewer #1 (R1.2). strategy == null when integrity off.
    private static final Mode[] MODES = new Mode[]{
            new Mode("STANDARD",       false, false, null),
            new Mode("SIGNATURE_ONLY", false, true,  null),
            new Mode("CHAIN_ONLY",     true,  false, IntegrityService.Strategy.CHECKPOINT),
            new Mode("STRICT_ONLY",    true,  false, IntegrityService.Strategy.STRICT),
            new Mode("FULL_HYBRID",    true,  true,  IntegrityService.Strategy.CHECKPOINT)
    };

    private static final class Mode {
        final String name;
        final boolean integrityEnabled;
        final boolean signatureEnabled;
        final IntegrityService.Strategy strategy; // null when integrity disabled

        Mode(String name, boolean integrityEnabled, boolean signatureEnabled, IntegrityService.Strategy strategy) {
            this.name = name;
            this.integrityEnabled = integrityEnabled;
            this.signatureEnabled = signatureEnabled;
            this.strategy = strategy;
        }
    }

    public static void main(String[] args) throws Exception {
        // MUST be the very first line: Spring DevTools' restart classloader breaks the CGLIB DAO
        // proxies in this standalone benchmark (NoClassDefFoundError on project enums loaded via
        // RestartClassLoader, e.g. enums/State). Disabling restart as a SYSTEM property here is
        // honored early by DevTools, unlike passing it through SpringApplicationBuilder.properties()
        // which is read after the restart launcher has already kicked in.
        System.setProperty("spring.devtools.restart.enabled", "false");
        System.setProperty("spring.devtools.livereload.enabled", "false");

        // Stage selector lets the long benchmark run in independent parts (run them on different
        // nights), each writing its own timestamped CSV so a crash never loses earlier stages.
        //   program argument "single"     -> single-thread Table 3 (incl. STRICT_ONLY)
        //   program argument "concurrent" -> concurrency benchmark only
        //   program argument "ksens"      -> K-sensitivity only
        //   no argument / "all"           -> everything in sequence (legacy behaviour)
        String stage = "all";
        for (String a : args) {
            if (a != null && !a.startsWith("--") && !a.isBlank()) {
                stage = a.trim().toLowerCase(Locale.US);
                break;
            }
        }

        Map<String, Object> props = new HashMap<>();
        props.put("spring.main.web-application-type", "none");

        // Disable DevTools restart for cleaner benchmark runs
        props.put("spring.devtools.restart.enabled", "false");

        // Connection pool must be >= max concurrent threads (32) so the pool itself is NOT the
        // bottleneck in the concurrency benchmark — otherwise we would measure pool starvation
        // instead of checkpointLock / last_hash contention. 64 leaves headroom.
        props.put("spring.datasource.hikari.maximum-pool-size", "64");

        ConfigurableApplicationContext ctx = new SpringApplicationBuilder(LicensedbApplication.class)
                .properties(props)
                .run(args);

        try {
            runBench(ctx, stage);
        } finally {
            ctx.close();
        }
    }

    private static void runBench(ConfigurableApplicationContext ctx, String stage) throws Exception {
        JdbcTemplate jdbc = ctx.getBean(JdbcTemplate.class);
        FreqDao freqDao = ctx.getBean(FreqDao.class);
        FreqCrudService freqCrudService = ctx.getBean(FreqCrudService.class);
        IntegrityService integrityService = ctx.getBean(IntegrityService.class);

        boolean doSingle     = stage.equals("all") || stage.equals("single");
        boolean doConcurrent = stage.equals("all") || stage.equals("concurrent");
        boolean doKsens      = stage.equals("all") || stage.equals("ksens");

        if (!doSingle && !doConcurrent && !doKsens) {
            System.out.println("[BENCH] unknown stage '" + stage + "'. Use: single | concurrent | ksens | all");
            return;
        }

        // One timestamped CSV per stage => partial results survive a crash / overnight reboot.
        String stamp = new java.text.SimpleDateFormat("yyyyMMdd-HHmmss").format(new java.util.Date());
        String outPath = Paths.get("bench-results-" + stage + "-" + stamp + ".csv").toAbsolutePath().toString();
        System.out.println("[BENCH] stage=" + stage + " | output=" + outPath);

        // For printing overhead vs STANDARD using medians:
        Map<String, BenchResult[]> medianResultsByMode = new LinkedHashMap<>();

        try (FileWriter fw = new FileWriter(outPath, false)) {
            fw.write("mode,n_ops,repeat,total_ms,avg_ms_per_op,tps,threads,mean_ms,stddev_ms,min_ms,max_ms,iqr_ms,k_value\n");

            if (doSingle) {
                for (Mode m : MODES) {
                    BenchResult[] medians = runOneModeWithRepeats(
                            m, jdbc, freqDao, freqCrudService, integrityService, fw
                    );
                    medianResultsByMode.put(m.name, medians);
                }

                // Print comparisons vs STANDARD (median-based)
                BenchResult[] base = medianResultsByMode.get("STANDARD");
                if (base == null) {
                    System.out.println("No STANDARD baseline results - cannot compute overhead.");
                } else {
                    System.out.println("\n=== OVERHEAD vs STANDARD (median total time) ===");
                    for (String modeName : medianResultsByMode.keySet()) {
                        if ("STANDARD".equals(modeName)) continue;
                        BenchResult[] r = medianResultsByMode.get(modeName);
                        System.out.println("\n-- " + modeName + " --");
                        for (int i = 0; i < SIZES.length; i++) {
                            BenchResult b = base[i];
                            BenchResult x = r[i];
                            if (b == null || x == null || b.totalMs <= 0.0) {
                                System.out.printf("N=%d | skipped (insufficient data)%n", SIZES[i]);
                                continue;
                            }
                            double oh = 100.0 * (x.totalMs - b.totalMs) / b.totalMs;
                            System.out.printf(Locale.US,
                                    "N=%d | standard=%.2f ms | %s=%.2f ms | overhead=%.2f%%%n",
                                    SIZES[i], b.totalMs, modeName, x.totalMs, oh
                            );
                        }
                    }

                    System.out.println("\n=== Throughput retained vs STANDARD (median TPS) ===");
                    for (String modeName : medianResultsByMode.keySet()) {
                        if ("STANDARD".equals(modeName)) continue;
                        BenchResult[] r = medianResultsByMode.get(modeName);
                        System.out.println("\n-- " + modeName + " --");
                        for (int i = 0; i < SIZES.length; i++) {
                            BenchResult b = base[i];
                            BenchResult x = r[i];
                            if (b == null || x == null || b.tps <= 0.0) {
                                System.out.printf("N=%d | skipped (insufficient data)%n", SIZES[i]);
                                continue;
                            }
                            double retained = 100.0 * (x.tps / b.tps);
                            System.out.printf(Locale.US,
                                    "N=%d | standard=%.2f TPS | %s=%.2f TPS | retained=%.2f%%%n",
                                    SIZES[i], b.tps, modeName, x.tps, retained
                            );
                        }
                    }
                }
            }

            if (doConcurrent) {
                runConcurrentBench(jdbc, freqDao, freqCrudService, integrityService, fw);
            }

            if (doKsens) {
                runKSensitivityExperiment(jdbc, freqDao, freqCrudService, integrityService, fw);
            }

            System.out.println("\nCSV saved to: " + outPath);
        }
    }

    private static BenchResult[] runOneModeWithRepeats(
            Mode mode,
            JdbcTemplate jdbc,
            FreqDao freqDao,
            FreqCrudService freqCrudService,
            IntegrityService integrityService,
            FileWriter fw
    ) throws Exception {

        System.out.println("\n=== MODE: " + mode.name + " ===");

        // Configure toggles
        integrityService.setEnabled(mode.integrityEnabled);
        freqCrudService.setSignatureEnabled(mode.signatureEnabled);

        // If integrity enabled, use the mode's chaining strategy (CHECKPOINT or STRICT)
        if (mode.integrityEnabled) {
            integrityService.setStrategy(mode.strategy);
            if (mode.strategy == IntegrityService.Strategy.CHECKPOINT) {
                integrityService.setCheckpointBatchSize(CHECKPOINT_K);
            }
        }

        BenchResult[] medianResults = new BenchResult[SIZES.length];

        for (int idx = 0; idx < SIZES.length; idx++) {
            int nRequested = SIZES[idx];

            // Find candidate IDs (avoid dirty sentinel values causing enum/date issues)
            List<Long> ids = jdbc.queryForList(
                    "select f.ID " +
                            "from freq f " +
                            "join site s on s.ID = f.IDsite " +
                            "join owner ow on ow.ID = s.IDowner " +
                            "where f.type <> 4294967295 and f.mode <> 4294967295 " +
                            "and s.polar <> 4294967295 " +
                            "order by f.ID asc limit ?",
                    Long.class,
                    nRequested
            );

            if (ids == null || ids.isEmpty()) {
                System.out.printf("N=%d | no records available -> skipped%n", nRequested);
                medianResults[idx] = BenchResult.zero(mode.name, nRequested);
                continue;
            }

            int n = Math.min(nRequested, ids.size());

            // Prefetch views OUTSIDE measurement (so we measure writes)
            List<FreqView> views = ids.subList(0, n).stream()
                    .map(id -> {
                        try {
                            return freqDao.getById(id);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    })
                    .collect(Collectors.toList());

            // Warm-up
            warmup(freqCrudService, views);

            // Repeat measurements
            List<Double> totals = new ArrayList<>(REPEATS);
            List<Double> tpsList = new ArrayList<>(REPEATS);

            for (int rep = 1; rep <= REPEATS; rep++) {
                resetIntegrityTablesIfPresent(jdbc);

                long t0 = System.nanoTime();
                for (int i = 0; i < n; i++) {
                    FreqView v = views.get(i);

                    // Change nominal slightly so UPDATE is real; alternate sign to avoid drift
                    double base = v.getFreqModel().getNominal();
                    double delta = (rep % 2 == 0) ? -0.001 : 0.001;
                    v.getFreqModel().setNominal(base + delta);

                    freqCrudService.updateFreqOnly(v);
                }
                long t1 = System.nanoTime();

                double totalMs = (t1 - t0) / 1_000_000.0;
                double avgMs = totalMs / n;
                double tps = 1000.0 * n / Math.max(1.0, totalMs);

                totals.add(totalMs);
                tpsList.add(tps);

                System.out.printf(Locale.US,
                        "N=%d | rep=%d | total=%.2f ms | avg=%.6f ms/op | TPS=%.2f%n",
                        n, rep, totalMs, avgMs, tps
                );

                fw.write(String.format(Locale.US,
                        "%s,%d,%d,%.3f,%.6f,%.2f,1,,,,,,\n",
                        mode.name, n, rep, totalMs, avgMs, tps
                ));
                fw.flush();
            }

            // Summary statistics
            double totalMedian = median(totals);
            double tpsMedian   = median(tpsList);
            double avgMedian   = totalMedian / n;
            double totalMean   = mean(totals);
            double totalStddev = stddev(totals);
            double totalMin    = min(totals);
            double totalMax    = max(totals);
            double totalIqr    = iqr(totals);

            medianResults[idx] = new BenchResult(mode.name, n, totalMedian, avgMedian, tpsMedian,
                    totalMean, totalStddev, totalMin, totalMax, totalIqr);
            System.out.printf(Locale.US,
                    "N=%d | MEDIAN=%.2f ms | MEAN=%.2f ms | SD=%.2f ms | MIN=%.2f ms | MAX=%.2f ms | IQR=%.2f ms | MEDIAN TPS=%.2f%n",
                    n, totalMedian, totalMean, totalStddev, totalMin, totalMax, totalIqr, tpsMedian
            );
            fw.write(String.format(Locale.US,
                    "%s,%d,-1,%.3f,%.6f,%.2f,1,%.3f,%.3f,%.3f,%.3f,%.3f,\n",
                    mode.name, n, totalMedian, avgMedian, tpsMedian,
                    totalMean, totalStddev, totalMin, totalMax, totalIqr
            ));
            fw.flush();
        }

        // Ensure no nulls (safety)
        for (int i = 0; i < medianResults.length; i++) {
            if (medianResults[i] == null) {
                medianResults[i] = BenchResult.zero(mode.name, SIZES[i]);
            }
        }

        return medianResults;
    }

    private static void runKSensitivityExperiment(
            JdbcTemplate jdbc,
            FreqDao freqDao,
            FreqCrudService freqCrudService,
            IntegrityService integrityService,
            FileWriter fw
    ) throws Exception {
        System.out.println("\n=== K-SENSITIVITY EXPERIMENT (N=" + K_SENSITIVITY_N + ", repeats=" + REPEATS + ") ===");

        // Hardcoded STANDARD N=100000 median total_ms from the previous full benchmark run
        final double standardBaselineMs = 327583.533;
        System.out.printf(Locale.US, "[INFO] Using hardcoded STANDARD baseline: %.3f ms%n", standardBaselineMs);

        // Prefetch IDs and views once for all (mode, K) combinations
        List<Long> ids;
        try {
            ids = jdbc.queryForList(
                    "select f.ID " +
                    "from freq f " +
                    "join site s on s.ID = f.IDsite " +
                    "join owner ow on ow.ID = s.IDowner " +
                    "where f.type <> 4294967295 and f.mode <> 4294967295 " +
                    "and s.polar <> 4294967295 " +
                    "order by f.ID asc limit ?",
                    Long.class, K_SENSITIVITY_N
            );
        } catch (Exception e) {
            System.out.println("ERROR: DB connection failed while fetching IDs — datasource may be closed: " + e.getMessage());
            return;
        }

        if (ids == null || ids.isEmpty()) {
            System.out.println("No records available for K-sensitivity experiment -> skipped");
            return;
        }

        int n = Math.min(K_SENSITIVITY_N, ids.size());
        List<FreqView> views;
        try {
            views = ids.subList(0, n).stream()
                    .map(id -> {
                        try { return freqDao.getById(id); }
                        catch (Exception e) { throw new RuntimeException(e); }
                    })
                    .collect(Collectors.toList());
        } catch (Exception e) {
            System.out.println("ERROR: DB connection failed while prefetching views — datasource may be closed: " + e.getMessage());
            return;
        }

        // Only CHAIN_ONLY and FULL_HYBRID
        Mode[] kModes = Arrays.stream(MODES)
                .filter(m -> "CHAIN_ONLY".equals(m.name) || "FULL_HYBRID".equals(m.name))
                .toArray(Mode[]::new);

        // modeName -> k -> median BenchResult
        Map<String, Map<Integer, BenchResult>> kResults = new LinkedHashMap<>();

        for (Mode mode : kModes) {
            kResults.put(mode.name, new LinkedHashMap<>());

            for (int k : K_SENSITIVITY_K_VALUES) {
                System.out.printf("%nK-sensitivity | MODE=%s | K=%d%n", mode.name, k);

                integrityService.setEnabled(mode.integrityEnabled);
                freqCrudService.setSignatureEnabled(mode.signatureEnabled);
                integrityService.setStrategy(IntegrityService.Strategy.CHECKPOINT);
                integrityService.setCheckpointBatchSize(k);

                warmup(freqCrudService, views);

                List<Double> totals = new ArrayList<>(REPEATS);
                List<Double> tpsList = new ArrayList<>(REPEATS);

                for (int rep = 1; rep <= REPEATS; rep++) {
                    resetIntegrityTablesIfPresent(jdbc);

                    long t0 = System.nanoTime();
                    for (int i = 0; i < n; i++) {
                        FreqView v = views.get(i);
                        double base = v.getFreqModel().getNominal();
                        double delta = (rep % 2 == 0) ? -0.001 : 0.001;
                        v.getFreqModel().setNominal(base + delta);
                        freqCrudService.updateFreqOnly(v);
                    }
                    long t1 = System.nanoTime();

                    double totalMs = (t1 - t0) / 1_000_000.0;
                    double avgMs = totalMs / n;
                    double tps = 1000.0 * n / Math.max(1.0, totalMs);

                    totals.add(totalMs);
                    tpsList.add(tps);

                    System.out.printf(Locale.US,
                            "K=%d | rep=%d | total=%.2f ms | avg=%.6f ms/op | TPS=%.2f%n",
                            k, rep, totalMs, avgMs, tps
                    );

                    fw.write(String.format(Locale.US,
                            "%s,%d,%d,%.3f,%.6f,%.2f,1,,,,,%d\n",
                            mode.name, n, rep, totalMs, avgMs, tps, k
                    ));
                    fw.flush();
                }

                double totalMedian = median(totals);
                double tpsMedian   = median(tpsList);
                double avgMedian   = totalMedian / n;
                double totalMean   = mean(totals);
                double totalStddev = stddev(totals);
                double totalMin    = min(totals);
                double totalMax    = max(totals);
                double totalIqr    = iqr(totals);

                BenchResult result = new BenchResult(mode.name, n, totalMedian, avgMedian, tpsMedian,
                        totalMean, totalStddev, totalMin, totalMax, totalIqr);
                kResults.get(mode.name).put(k, result);

                System.out.printf(Locale.US,
                        "K=%d | MEDIAN=%.2f ms | MEAN=%.2f ms | SD=%.2f ms | MIN=%.2f ms | MAX=%.2f ms | IQR=%.2f ms | MEDIAN TPS=%.2f%n",
                        k, totalMedian, totalMean, totalStddev, totalMin, totalMax, totalIqr, tpsMedian
                );

                // Summary row for this (mode, K)
                fw.write(String.format(Locale.US,
                        "%s,%d,-1,%.3f,%.6f,%.2f,1,%.3f,%.3f,%.3f,%.3f,%.3f,%d\n",
                        mode.name, n, totalMedian, avgMedian, tpsMedian,
                        totalMean, totalStddev, totalMin, totalMax, totalIqr, k
                ));
                fw.flush();
            }
        }

        // Print median overhead vs STANDARD
        System.out.println("\n=== K-SENSITIVITY: OVERHEAD vs STANDARD (N=" + K_SENSITIVITY_N + ", median total time) ===");
        for (Mode mode : kModes) {
            System.out.println("\n-- " + mode.name + " --");
            for (int k : K_SENSITIVITY_K_VALUES) {
                BenchResult r = kResults.get(mode.name).get(k);
                if (r == null || standardBaselineMs <= 0.0) {
                    System.out.printf("K=%d | skipped (insufficient data)%n", k);
                    continue;
                }
                double oh = 100.0 * (r.totalMs - standardBaselineMs) / standardBaselineMs;
                System.out.printf(Locale.US,
                        "K=%d | standard=%.2f ms | %s=%.2f ms | overhead=%.2f%%%n",
                        k, standardBaselineMs, mode.name, r.totalMs, oh
                );
            }
        }
    }

    private static void warmup(FreqCrudService freqCrudService, List<FreqView> views) {
        int m = Math.min(views.size(), 200); // no need for 10k distinct records
        for (int i = 0; i < WARMUP_OPS; i++) {
            FreqView v = views.get(i % m);

            double base = v.getFreqModel().getNominal();
            v.getFreqModel().setNominal(base + 0.0001);

            try {
                freqCrudService.updateFreqOnly(v);
            } catch (Exception ignored) {
                // warm-up is best effort
            }
        }
    }

    private static void resetIntegrityTablesIfPresent(JdbcTemplate jdbc) {
        // strict-chain tables (if exist)
        try {
            jdbc.update("delete from freq_integrity_log");
            jdbc.update("update integrity_chain_state set last_hash='GENESIS' where id=1");
        } catch (Exception ignored) {}

        // checkpoint-chain tables (if exist)
        try {
            jdbc.update("delete from freq_integrity_event");
            jdbc.update("delete from integrity_checkpoint");
            jdbc.update("update integrity_checkpoint_state set last_checkpoint_hash='GENESIS', next_batch_no=1 where id=1");
        } catch (Exception ignored) {}
    }

    private static void runConcurrentBench(
            JdbcTemplate jdbc,
            FreqDao freqDao,
            FreqCrudService freqCrudService,
            IntegrityService integrityService,
            FileWriter fw
    ) throws Exception {
        int maxThreads = CONCURRENT_THREAD_COUNTS[CONCURRENT_THREAD_COUNTS.length - 1];
        System.out.println("\n=== CONCURRENT BENCHMARK (E2+E3) | ops/thread=" + CONCURRENT_OPS_PER_THREAD
                + " | records/thread=" + CONCURRENT_RECORDS_PER_THREAD
                + " | repeats=" + CONCURRENT_REPEATS + " | up to " + maxThreads + " threads ===");

        // Prefetch a large pool of DISTINCT records once. Each thread later gets a DISJOINT slice,
        // so the only shared contention point is the integrity layer (checkpointLock for CHECKPOINT,
        // global last_hash for STRICT) — NOT InnoDB row locks on the same rows. This isolates exactly
        // the effect Reviewer #1 asked about, and avoids shared-object mutation races on FreqView.
        List<Long> ids = jdbc.queryForList(
                "select f.ID " +
                "from freq f " +
                "join site s on s.ID = f.IDsite " +
                "join owner ow on ow.ID = s.IDowner " +
                "where f.type <> 4294967295 and f.mode <> 4294967295 " +
                "and s.polar <> 4294967295 " +
                "order by f.ID asc limit ?",
                Long.class, CONCURRENT_MAX_RECORDS
        );
        int need = maxThreads * CONCURRENT_RECORDS_PER_THREAD;
        if (ids == null || ids.size() < need) {
            System.out.printf("Not enough distinct records for disjoint slices: need %d, have %d -> concurrent bench skipped%n",
                    need, (ids == null ? 0 : ids.size()));
            return;
        }
        final List<FreqView> allViews = ids.stream()
                .map(id -> { try { return freqDao.getById(id); } catch (Exception e) { throw new RuntimeException(e); } })
                .collect(Collectors.toList());

        for (Mode m : MODES) {
            integrityService.setEnabled(m.integrityEnabled);
            freqCrudService.setSignatureEnabled(m.signatureEnabled);
            if (m.integrityEnabled) {
                integrityService.setStrategy(m.strategy);
                if (m.strategy == IntegrityService.Strategy.CHECKPOINT) {
                    integrityService.setCheckpointBatchSize(CHECKPOINT_K);
                }
            }

            System.out.println("\n--- MODE: " + m.name + " ---");

            for (int threadCount : CONCURRENT_THREAD_COUNTS) {
                // warm-up once per (mode, threadCount) to stabilize JIT and the connection pool
                runConcurrentOnce(threadCount, allViews, freqCrudService, true);

                List<Double> aggTpsList = new ArrayList<>(CONCURRENT_REPEATS);
                List<Double> wallList   = new ArrayList<>(CONCURRENT_REPEATS);

                for (int rep = 1; rep <= CONCURRENT_REPEATS; rep++) {
                    resetIntegrityTablesIfPresent(jdbc);
                    double[] res = runConcurrentOnce(threadCount, allViews, freqCrudService, false);
                    double wallMs = res[0];
                    double aggTps = res[1];
                    aggTpsList.add(aggTps);
                    wallList.add(wallMs);

                    System.out.printf(Locale.US,
                            "MODE=%s | threads=%d | rep=%d | wall=%.2f ms | aggTPS=%.2f%n",
                            m.name, threadCount, rep, wallMs, aggTps);

                    // per-rep row: total_ms=wallMs, tps=aggTps, threads=threadCount, repeat=rep
                    fw.write(String.format(Locale.US,
                            "%s,%d,%d,%.3f,%.6f,%.2f,%d,,,,,,\n",
                            m.name, CONCURRENT_OPS_PER_THREAD, rep, wallMs,
                            wallMs / (threadCount * (double) CONCURRENT_OPS_PER_THREAD), aggTps, threadCount));
                    fw.flush();
                }

                // summary row (repeat = -1): median wall + dispersion statistics of aggregate TPS
                double wallMed = median(wallList);
                double tpsMed  = median(aggTpsList);
                double tpsMean = mean(aggTpsList);
                double tpsSd   = stddev(aggTpsList);
                double tpsMin  = min(aggTpsList);
                double tpsMax  = max(aggTpsList);
                double tpsIqr  = iqr(aggTpsList);

                System.out.printf(Locale.US,
                        "MODE=%s | threads=%d | MEDIAN aggTPS=%.2f | IQR=%.2f | SD=%.2f | wall(med)=%.2f ms%n",
                        m.name, threadCount, tpsMed, tpsIqr, tpsSd, wallMed);

                // summary row stores TPS stats in the mean/sd/min/max/iqr columns (computed over aggTPS)
                fw.write(String.format(Locale.US,
                        "%s,%d,-1,%.3f,%.6f,%.2f,%d,%.3f,%.3f,%.3f,%.3f,%.3f,\n",
                        m.name, CONCURRENT_OPS_PER_THREAD, wallMed,
                        wallMed / (threadCount * (double) CONCURRENT_OPS_PER_THREAD), tpsMed, threadCount,
                        tpsMean, tpsSd, tpsMin, tpsMax, tpsIqr));
                fw.flush();
            }
        }
    }

    /**
     * Executes ONE concurrent run: {@code threadCount} threads, each updating its OWN disjoint slice
     * of {@link #CONCURRENT_RECORDS_PER_THREAD} records, each performing the configured number of
     * updates. All threads are released simultaneously (barrier) so wall-clock time reflects steady
     * concurrency rather than thread-startup skew. Returns {@code {wallMs, aggTps}}.
     */
    private static double[] runConcurrentOnce(int threadCount, List<FreqView> allViews,
                                              FreqCrudService freqCrudService, boolean warmup)
            throws InterruptedException {
        final int opsPerThread = warmup ? Math.min(2000, CONCURRENT_OPS_PER_THREAD) : CONCURRENT_OPS_PER_THREAD;

        java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(threadCount);
        java.util.concurrent.CountDownLatch ready = new java.util.concurrent.CountDownLatch(threadCount);
        java.util.concurrent.CountDownLatch start = new java.util.concurrent.CountDownLatch(1);
        java.util.concurrent.CountDownLatch done  = new java.util.concurrent.CountDownLatch(threadCount);

        for (int t = 0; t < threadCount; t++) {
            final int tIdx = t;
            pool.submit(() -> {
                // disjoint slice: thread t owns records [t*RPT, (t+1)*RPT)
                int from = tIdx * CONCURRENT_RECORDS_PER_THREAD;
                int to = Math.min(from + CONCURRENT_RECORDS_PER_THREAD, allViews.size());
                List<FreqView> slice = allViews.subList(from, to);
                double delta = (tIdx % 2 == 0) ? 0.001 : -0.001;
                ready.countDown();
                try { start.await(); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                try {
                    int sz = slice.size();
                    for (int i = 0; i < opsPerThread; i++) {
                        FreqView v = slice.get(i % sz);
                        v.getFreqModel().setNominal(v.getFreqModel().getNominal() + delta);
                        freqCrudService.updateFreqOnly(v);
                    }
                } catch (Exception ignored) {
                } finally {
                    done.countDown();
                }
            });
        }

        ready.await();                 // all threads built their slice and are parked on the barrier
        long wallStart = System.nanoTime();
        start.countDown();             // release all threads at once
        done.await();
        long wallEnd = System.nanoTime();
        pool.shutdown();

        double wallMs = (wallEnd - wallStart) / 1_000_000.0;
        double totalOps = (double) threadCount * opsPerThread;
        double aggTps = totalOps / Math.max(1.0, wallMs) * 1000.0;
        return new double[]{wallMs, aggTps};
    }

    private static double mean(List<Double> xs) {
        if (xs == null || xs.isEmpty()) return 0.0;
        double sum = 0.0;
        for (double x : xs) sum += x;
        return sum / xs.size();
    }

    private static double stddev(List<Double> xs) {
        if (xs == null || xs.size() < 2) return 0.0;
        double m = mean(xs);
        double sum = 0.0;
        for (double x : xs) sum += (x - m) * (x - m);
        return Math.sqrt(sum / (xs.size() - 1));
    }

    private static double min(List<Double> xs) {
        if (xs == null || xs.isEmpty()) return 0.0;
        double m = xs.get(0);
        for (double x : xs) if (x < m) m = x;
        return m;
    }

    private static double max(List<Double> xs) {
        if (xs == null || xs.isEmpty()) return 0.0;
        double m = xs.get(0);
        for (double x : xs) if (x > m) m = x;
        return m;
    }

    private static double iqr(List<Double> xs) {
        if (xs == null || xs.isEmpty()) return 0.0;
        List<Double> s = new ArrayList<>(xs);
        s.sort(Double::compareTo);
        return percentile(s, 75.0) - percentile(s, 25.0);
    }

    private static double percentile(List<Double> sorted, double p) {
        int n = sorted.size();
        if (n == 1) return sorted.get(0);
        double idx = p / 100.0 * (n - 1);
        int lo = (int) Math.floor(idx);
        int hi = (int) Math.ceil(idx);
        if (lo == hi) return sorted.get(lo);
        return sorted.get(lo) * (1.0 - (idx - lo)) + sorted.get(hi) * (idx - lo);
    }

    private static double median(List<Double> xs) {
        if (xs == null || xs.isEmpty()) return 0.0;
        List<Double> s = new ArrayList<>(xs);
        s.sort(Double::compareTo);
        int n = s.size();
        if (n % 2 == 1) return s.get(n / 2);
        return 0.5 * (s.get(n / 2 - 1) + s.get(n / 2));
    }

    private static final class BenchResult {
        final String mode;
        final int nOps;
        final double totalMs;
        final double avgMsPerOp;
        final double tps;
        final double mean;
        final double stddev;
        final double min;
        final double max;
        final double iqr;

        BenchResult(String mode, int nOps, double totalMs, double avgMsPerOp, double tps,
                    double mean, double stddev, double min, double max, double iqr) {
            this.mode = mode;
            this.nOps = nOps;
            this.totalMs = totalMs;
            this.avgMsPerOp = avgMsPerOp;
            this.tps = tps;
            this.mean = mean;
            this.stddev = stddev;
            this.min = min;
            this.max = max;
            this.iqr = iqr;
        }

        static BenchResult zero(String mode, int nOps) {
            return new BenchResult(mode, nOps, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        }
    }
}
