# GAS-artifact v1.2

Software and benchmark artifact for the manuscript:

**Application-Layer Integrity Protection and Temporal Administrative Control for Centralized State Registries: Implementation and Evaluation** (ARRAY-D-26-01585, Array, Elsevier).

This release (v1.2) accompanies the revised manuscript. It adds an isolated cryptographic microbenchmark (JMH), a staged service-layer benchmark including the STRICT hash-chain mode, a 1-32-thread concurrency benchmark, raw measurement data, plotting/analysis code, and the figure files used in the revised paper.

Supersedes v1.1 (DOI 10.5281/zenodo.19478931). Before final publication of this record, replace this sentence with the new Zenodo version DOI minted/reserved for v1.2 if desired.

## Reference environment
- CPU: Intel Xeon E5-2680 v3 (2.50 GHz); 32 GB RAM
- OS: Windows 10 Pro 22H2 (build 19045)
- Storage: local NVMe SSD (Kingston SNVS250)
- DB: MySQL 8.0 / InnoDB (default configuration unless noted)
- JDK: Java 17 (Amazon Corretto 17.0.18)
- App: Spring Boot 2.7 service (licensedb)

## Contents

### code/
- `HmacMicrobenchmark.java` - JMH microbenchmark isolating fingerprint cost (Algorithm 1, Algorithm 2, full fingerprint). Produces `e1-hmac-jmh.csv`; used for Table 6.
- `HmacIsolationRunner.java` - dependency-free fallback (plain `nanoTime`) for the same measurement.
- `MicrobenchmarkRunner.java` - staged service-layer benchmark. Program argument: `single` (Tables 3-4), `concurrent` (Table 5 and Figures 5-6), `ksens`, or `all`. Each stage writes its own timestamped CSV.
- `analyze_bench.py` - recomputes median, IQR, SD and bootstrap 95% confidence intervals; auto-detects single-thread versus concurrent CSVs and renders analysis tables and figures.

### data/ (raw measurements)
- `e1-hmac-jmh.csv` - Table 6 (JMH; 5 forks; 50 measurements).
- `bench-results-single-20260604-065611.csv` - Tables 3-4 and Figures 3-4 (single thread; 30 runs).
- `bench-results-concurrent-20260605-134051.csv` - Table 5 and Figures 5-6 (1-32 threads; 16 runs; 3,000 ops/thread).

### figures/
- `fig_3_single_throughput.png` - Figure 3 (single-thread median throughput vs N; non-strict configurations).
- `fig_4_single_overhead.png` - Figure 4 (single-thread median overhead vs STANDARD; non-strict configurations; STRICT omitted because it is off-scale).
- `fig_5_concurrent_tps.png` - Figure 5 (concurrent aggregate TPS vs threads).
- `fig_6_scalability.png` - Figure 6 (scalability, TPS(T)/TPS(1)).
- `graphical_abstract.png` - graphical abstract.

## Reproduce
1. Build the `licensedb` Spring Boot app (Java 17, Maven) against a MySQL 8 instance holding the registry schema.
2. Table 6: run `HmacMicrobenchmark.main()` -> `e1-hmac-jmh.csv` (or `HmacIsolationRunner` without JMH).
3. Tables 3-4: run `MicrobenchmarkRunner` with program argument `single`.
4. Table 5 / Figures 5-6: run `MicrobenchmarkRunner` with program argument `concurrent` (connection pool >= max threads; disjoint per-thread record partitions).
5. Analysis: run `python code/analyze_bench.py data/<stage-csv> --out <dir>` to regenerate analysis tables and plots.

## Notes
- Medians are the primary statistic (robust to workstation OS interference); 95% CIs are computed by bootstrap (default 10,000 resamples).
- The single-node setting is used to isolate concurrent contention; network-separated and multi-node deployments are future work.
- Operational registry data are not included due to administrative confidentiality.
